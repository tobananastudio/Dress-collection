/* Banana Studio — service worker: makes the catalogue load instantly and work offline. */
const VERSION = "bs-__BUILD__";          // stamped automatically by build.yml
const CORE = [
  "./",
  "index.html",
  "css/style.css",
  "js/products.js",
  "js/app.js",
  "manifest.webmanifest",
  "assets/logo.png",
  "assets/favicon.png",
  "assets/icon-192.png",
  "assets/icon-512.png",
  "assets/apple-touch-icon.png",
  "assets/images/thumbs/pant-01.jpg",
  "assets/images/thumbs/pant-02.jpg",
  "assets/images/thumbs/pant-03.jpg",
  "assets/images/thumbs/pant-04.jpg",
  "assets/images/thumbs/pant-05.jpg",
  "assets/images/thumbs/pant-06.jpg",
  "assets/images/thumbs/pant-07.jpg",
  "assets/images/thumbs/pant-08.jpg",
  "assets/images/thumbs/pant-09.jpg",
  "assets/images/thumbs/pant-10.jpg",
  "assets/images/thumbs/pant-11.jpg",
  "assets/images/thumbs/pant-12.jpg",
  "assets/images/thumbs/pant-13.jpg"
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(CORE.map((u) => new Request(u, { cache: "reload" })))).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  const sameOrigin = url.origin === self.location.origin;
  const isFont = url.hostname === "fonts.googleapis.com" || url.hostname === "fonts.gstatic.com";
  if (!sameOrigin && !isFont) return;

  // Open the app: always show the cached shell instantly, refresh it in the background.
  if (req.mode === "navigate") {
    e.respondWith(
      caches.match("index.html").then((cached) => {
        const fresh = fetch(req).then((res) => { if (res.ok) caches.open(VERSION).then((c) => c.put("index.html", res.clone())); return res; }).catch(() => cached);
        return cached || fresh;
      })
    );
    return;
  }

  // Everything else: cache first, update quietly in the background.
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then((cached) => {
      const fresh = fetch(req).then((res) => {
        if (res && (res.ok || res.type === "opaque")) caches.open(VERSION).then((c) => c.put(req, res.clone()));
        return res;
      }).catch(() => cached);
      return cached || fresh;
    })
  );
});
