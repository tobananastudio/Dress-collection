# Banana Studio — Pants Collection Catalogue

A premium, single-page HTML catalogue in a liquid-glass design (beige & olive).
Home page → **Our Collection** → 13 numbered cards → each card opens an elegant glass popup.

No build tools, no dependencies — plain HTML, CSS and JS.

## Put it online with GitHub Pages

1. Create a new GitHub repository (e.g. `banana-studio-catalogue`).
2. Upload everything from this folder (keep the `.github` folder — it contains `build.yml`).
3. In the repository go to **Settings → Pages → Build and deployment → Source** and choose **GitHub Actions**.
4. Push to `main`. The workflow in `.github/workflows/build.yml` publishes the site.
   Your link will be `https://<your-username>.github.io/<repository-name>/`.

> Prefer no Actions? Set **Source: Deploy from a branch → main / (root)** instead. The site works either way.

## Editing details

Open `js/products.js`. Every style has a number (`id: 1` … `id: 13`), a `name`, and a `spec(...)` line holding its fabric:

```js
{
  id: 6,
  name: "Straight Fit",
  image: "assets/images/pant-06.jpg",
  thumb: "assets/images/thumbs/pant-06.jpg",   // small version used on the cards page
  specs: spec("Rigid Denim (100% Cotton), Stretch Denim, Heavy Weight Denim")
}
```

Colour, sizes, MOQ and price are shared by all styles in the `COMMON` block at the top of the file — change them once there.
Any spec left empty (`""`) is hidden automatically. To show an **Enquire** button in every popup, set `enquiryEmail` at the top.

## Replacing an image

Overwrite the file in `assets/images/` (about 1000 px wide) **and** its small copy in `assets/images/thumbs/` (about 640 px wide) using the same file name.

## Structure

```
index.html
css/style.css
js/products.js      ← edit your details here
js/app.js
assets/logo.png
assets/images/pant-01.jpg … pant-13.jpg
assets/images/thumbs/…   ← light copies for the cards page
.github/workflows/build.yml
```
