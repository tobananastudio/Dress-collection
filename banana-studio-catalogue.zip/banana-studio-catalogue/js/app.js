/* ==========================================================
   BANANA STUDIO — Catalogue behaviour
   Views: home → collection → popup (with hash routing)
     #            home
     #collection  grid of 14 cards
     #style-05    popup for card 05
   ========================================================== */
(function () {
  "use strict";

  var CFG = window.BANANA_CONFIG || {};
  var DATA = window.PRODUCTS || [];
  var TOTAL = DATA.length;

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var pad = function (n) { return String(n).padStart(2, "0"); };
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  var el = {
    home: $("#home"), collection: $("#collection"), grid: $("#grid"),
    enter: $("#enter"), homeLink: $("#home-link"),
    modal: $("#modal"), panel: $(".modal__panel"), body: $("#m-body"),
    img: $("#m-img"), chip: $("#m-chip"), count: $("#m-count"), title: $("#m-title"),
    desc: $("#m-desc"), specs: $("#m-specs"), enquire: $("#m-enquire"),
    prev: $("#m-prev"), next: $("#m-next")
  };

  var state = { index: -1, open: false, pushed: false, lastCard: null, closing: false };

  /* ---------- Static text from config ---------- */
  if ($("#season")) $("#season").textContent = CFG.season || "2026";
  if ($("#year")) $("#year").textContent = new Date().getFullYear();
  document.querySelectorAll(".topbar__count, .hero__meta span:first-child").forEach(function (n) {
    n.textContent = TOTAL + " Styles";
  });

  var canHover = window.matchMedia("(hover: hover) and (pointer: fine)").matches, raf = false;

  /* ---------- Build the grid ---------- */
  var arrowSvg = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';

  DATA.forEach(function (p, i) {
    var li = document.createElement("li");
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "card";
    btn.style.setProperty("--i", i);
    btn.setAttribute("aria-label", "Open " + p.name);
    btn.dataset.index = i;
    btn.innerHTML =
      '<span class="card__img"><img src="' + (p.thumb || p.image) + '" alt="' + p.name + '" decoding="async"' + (i < 4 ? ' fetchpriority="high"' : '') + ' style="object-position:' + (p.position || "center") + '"></span>' +
      '<span class="card__num">' + pad(p.id) + '</span>' +
      '<span class="card__name"><span>' + p.name + '</span><span class="card__arrow">' + arrowSvg + '</span></span>';
    li.appendChild(btn);
    el.grid.appendChild(li);

    btn.addEventListener("click", function () {
      state.lastCard = btn;
      state.pushed = true;
      location.hash = "style-" + pad(p.id);
    });
    if (canHover) btn.addEventListener("pointermove", function (e) {
      if (raf) return; raf = true;
      requestAnimationFrame(function () {
        raf = false;
        var r = btn.getBoundingClientRect();
        btn.style.setProperty("--mx", (e.clientX - r.left) + "px");
        btn.style.setProperty("--my", (e.clientY - r.top) + "px");
      });
    });
  });
  var cards = Array.prototype.slice.call(el.grid.querySelectorAll(".card"));

  /* ---------- View switching ---------- */
  var currentView = "home";

  function setView(name) {
    if (name === currentView) return;
    var cur = currentView === "home" ? el.home : el.collection;
    var next = name === "home" ? el.home : el.collection;
    currentView = name;
    document.body.dataset.view = name;
    window.scrollTo(0, 0);

    cur.classList.remove("is-active");
    cur.classList.add("is-leaving");
    cur.setAttribute("inert", "");
    setTimeout(function () {
      if (cur.classList.contains("is-active")) return;
      cur.classList.remove("is-leaving");
      cur.hidden = true;
    }, reduceMotion ? 0 : 650);

    next.hidden = false;
    next.removeAttribute("inert");
    if (name === "collection") cards.forEach(function (c) { c.classList.remove("in"); });
    void next.offsetWidth; // force reflow so the transition runs from the hidden state
    next.classList.add("is-active");
    if (name === "collection") {
      setTimeout(warmFullImages, 1800);
      setTimeout(function () { cards.forEach(function (c) { c.classList.add("in"); }); }, 120);
    }
  }

  /* ---------- Warm the full-size photos in the background ---------- */
  var warmed = false;
  function warmFullImages() {
    if (warmed) return; warmed = true;
    var q = DATA.map(function (p) { return p.image; });
    (function next() {
      if (!q.length) return;
      var im = new Image(); im.decoding = "async"; im.src = q.shift();
      var go = function () { (window.requestIdleCallback || function (f) { setTimeout(f, 250); })(next); };
      im.onload = im.onerror = go;
    })();
  }

  /* ---------- Popup ---------- */
  function fillContent(i) {
    var p = DATA[i];
    state.index = i;
    el.img.src = p.image;
    el.img.alt = p.name;
    el.img.style.objectPosition = p.position || "center";
    el.chip.textContent = "No. " + pad(p.id);
    el.count.textContent = "Style " + pad(p.id) + " / " + pad(TOTAL);
    el.title.textContent = p.name;
    el.desc.textContent = p.description || "";

    el.specs.innerHTML = "";
    var specs = p.specs || {};
    Object.keys(specs).forEach(function (k) {
      var row = document.createElement("div");
      var dt = document.createElement("dt");
      var dd = document.createElement("dd");
      dt.textContent = k;
      var v = (specs[k] || "").toString().trim();
      if (!v) return; // empty fields are simply not shown
      dd.textContent = v;
      row.appendChild(dt); row.appendChild(dd);
      el.specs.appendChild(row);
    });

    if (CFG.enquiryEmail) {
      el.enquire.hidden = false;
      el.enquire.href = "mailto:" + CFG.enquiryEmail +
        "?subject=" + encodeURIComponent("Enquiry — " + p.name + " (Style " + pad(p.id) + ")");
    } else {
      el.enquire.hidden = true;
    }
    el.body.scrollTop = 0;

    // warm the neighbours
    [i - 1, i + 1].forEach(function (j) {
      var q = DATA[(j + TOTAL) % TOTAL]; if (q) { var im = new Image(); im.src = q.image; }
    });
  }

  var EXIT_MS = reduceMotion ? 0 : 300;

  function openModal(i) {
    if (state.closing) return;
    if (state.open) { goTo(i, i > state.index ? 1 : -1, true); return; }

    fillContent(i);
    state.open = true;
    el.modal.hidden = false;
    document.documentElement.classList.add("modal-open");
    document.body.classList.add("modal-on");
    el.home.setAttribute("inert", ""); el.collection.setAttribute("inert", "");
    void el.modal.offsetWidth;                 // start the CSS transition from the hidden state
    el.modal.classList.add("is-open");
    setTimeout(function () { el.panel.focus({ preventScroll: true }); }, 60);
  }

  function closeModal(done) {
    if (!state.open || state.closing) { if (done) done(); return; }
    state.closing = true;
    el.modal.classList.remove("is-open");
    setTimeout(function () {
      el.modal.hidden = true;
      state.open = false; state.closing = false; state.pushed = false;
      document.documentElement.classList.remove("modal-open");
      document.body.classList.remove("modal-on");
      el.collection.removeAttribute("inert");
      if (done) done();
    }, EXIT_MS);
  }

  function goTo(i, dir, fromRoute) {
    i = (i + TOTAL) % TOTAL;
    if (i === state.index) return;
    var d = dir || 1;
    if (!reduceMotion && el.img.animate) {
      el.img.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 140, fill: "forwards" }).onfinish = function () {
        fillContent(i);
        el.img.getAnimations().forEach(function (a) { a.cancel(); });
        el.img.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 260, easing: "ease-out" });
      };
    } else {
      fillContent(i);
    }
    if (!fromRoute) history.replaceState(history.state, "", "#style-" + pad(DATA[i].id));
  }

  /* ---------- Routing ---------- */
  function parseHash() {
    var h = location.hash.replace("#", "");
    var m = /^style-(\d{1,2})$/.exec(h);
    if (m) {
      var idx = DATA.findIndex(function (p) { return p.id === parseInt(m[1], 10); });
      if (idx > -1) return { view: "collection", modal: idx };
    }
    if (h === "collection") return { view: "collection", modal: -1 };
    return { view: "home", modal: -1 };
  }

  function route() {
    var r = parseHash();
    if (r.modal > -1) {
      setView("collection");
      openModal(r.modal);
    } else {
      var go = function () { setView(r.view); };
      if (state.open) closeModal(go); else go();
    }
  }
  window.addEventListener("hashchange", route);

  function requestClose() {
    if (!state.open) return;
    if (state.pushed) { history.back(); }
    else { history.replaceState(null, "", "#collection"); closeModal(); }
  }

  /* ---------- Events ---------- */
  el.enter.addEventListener("click", function () { location.hash = "collection"; });
  el.homeLink.addEventListener("click", function () { location.hash = ""; if (!location.hash) route(); });

  el.modal.addEventListener("click", function (e) {
    if (e.target.closest("[data-close]")) requestClose();
  });
  el.prev.addEventListener("click", function () { goTo(state.index - 1, -1); });
  el.next.addEventListener("click", function () { goTo(state.index + 1, 1); });

  document.addEventListener("keydown", function (e) {
    if (!state.open) return;
    if (e.key === "Escape") { e.preventDefault(); requestClose(); }
    else if (e.key === "ArrowLeft") goTo(state.index - 1, -1);
    else if (e.key === "ArrowRight") goTo(state.index + 1, 1);
    else if (e.key === "Tab") { // focus trap
      var f = el.panel.querySelectorAll('button:not([hidden]), a[href]:not([hidden])');
      if (!f.length) return;
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && (document.activeElement === first || document.activeElement === el.panel)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });

  // swipe left / right on touch devices
  var tx = 0, ty = 0;
  el.panel.addEventListener("touchstart", function (e) { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
  el.panel.addEventListener("touchend", function (e) {
    var dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty;
    if (Math.abs(dx) > 70 && Math.abs(dy) < 60) goTo(state.index + (dx < 0 ? 1 : -1), dx < 0 ? 1 : -1);
  }, { passive: true });


  /* ---------- App feel: offline support + "Add to home screen" ---------- */
  if ("serviceWorker" in navigator && /^https?:$/.test(location.protocol)) {
    window.addEventListener("load", function () { navigator.serviceWorker.register("sw.js").catch(function () {}); });
  }

  (function setupInstall() {
    var btn = $("#install"), hint = $("#hint"), hintText = $("#hint-text");
    if (!btn) return;
    var standalone = window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
    if (standalone) return;
    var deferred = null, timer = null;
    var ua = navigator.userAgent;
    var iOS = /iphone|ipad|ipod/i.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);

    function showHint(msg) {
      hintText.textContent = msg; hint.hidden = false;
      void hint.offsetWidth; hint.classList.add("show");
      clearTimeout(timer);
      timer = setTimeout(function () { hint.classList.remove("show"); setTimeout(function () { hint.hidden = true; }, 500); }, 7000);
    }

    window.addEventListener("beforeinstallprompt", function (e) { e.preventDefault(); deferred = e; btn.hidden = false; });
    window.addEventListener("appinstalled", function () { btn.hidden = true; deferred = null; });

    if (iOS) btn.hidden = false; // iOS has no install prompt – show instructions instead

    btn.addEventListener("click", function () {
      if (deferred) { deferred.prompt(); deferred.userChoice.finally(function () { deferred = null; btn.hidden = true; }); }
      else if (iOS) showHint("Tap the Share icon, then “Add to Home Screen”.");
      else showHint("Open your browser menu and choose “Install app” or “Add to Home screen”.");
    });
  })();

  /* ---------- Start ---------- */
  if (location.hash) route();
})();
