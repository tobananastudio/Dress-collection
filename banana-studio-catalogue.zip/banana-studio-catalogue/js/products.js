/* ==========================================================
   BANANA STUDIO — CATALOGUE DATA
   ----------------------------------------------------------
   This is the ONLY file you need to edit to change details.
   Each style is numbered 1–13 (the number badge on the card).
   Remove any spec line you don't want shown; lines left
   empty ("") are hidden automatically.
   ========================================================== */

window.BANANA_CONFIG = {
  company: "Banana Studio",
  tagline: "Garments Exporting Company",
  collectionTitle: "Pants Collection",
  season: "2026",
  // Add an email to show an "Enquire about this style" button in every popup.
  // Leave empty ("") to hide the button.
  enquiryEmail: ""
};

// Shared by every style (change once here)
var COMMON = {
  "Colour": "Dark Blue, Mid Blue, Light Blue, Black, Grey, Faded Blue, Navy Blue, Charcoal Grey, Beige, Olive Green etc.",
  "Size Range": "28, 30, 32, 34, 36, 38, 40",
  "MOQ": "As per client's preference",
  "Price": "Available at request"
};

function spec(fabric) {
  return Object.assign({ "Fabric": fabric }, COMMON);
}

window.PRODUCTS = [
  {
    id: 1,
    name: "Boot Cut",
    image: "assets/images/pant-01.jpg",
    thumb: "assets/images/thumbs/pant-01.jpg",
    position: "center 45%",
    description: "",
    specs: spec("Stretch Denim, Rigid Denim, Cotton Polyester Denim")
  },
  {
    id: 2,
    name: "Cargo Baggy",
    image: "assets/images/pant-02.jpg",
    thumb: "assets/images/thumbs/pant-02.jpg",
    position: "center 55%",
    description: "",
    specs: spec("Cotton Twill, Cotton Rip Stop, Poly Cotton, Nylon Fabric")
  },
  {
    id: 3,
    name: "Baggy Pant",
    image: "assets/images/pant-03.jpg",
    thumb: "assets/images/thumbs/pant-03.jpg",
    position: "center 55%",
    description: "",
    specs: spec("Denim, Cotton Twill, Polyester Viscose")
  },
  {
    id: 4,
    name: "Skin Fit",
    image: "assets/images/pant-04.jpg",
    thumb: "assets/images/thumbs/pant-04.jpg",
    position: "center 55%",
    description: "",
    specs: spec("Stretch Denim, Power Stretch Denim, Cotton Poly Stretch Denim")
  },
  {
    id: 5,
    name: "Jute Pants",
    image: "assets/images/pant-05.jpg",
    thumb: "assets/images/thumbs/pant-05.jpg",
    position: "center 55%",
    description: "",
    specs: spec("Jute Fabric, Linen Viscose, Cotton Slub")
  },
  {
    id: 6,
    name: "Straight Fit",
    image: "assets/images/pant-06.jpg",
    thumb: "assets/images/thumbs/pant-06.jpg",
    position: "center 55%",
    description: "",
    specs: spec("Rigid Denim (100% Cotton), Stretch Denim, Heavy Weight Denim")
  },
  {
    id: 7,
    name: "Wide Leg Jeans",
    image: "assets/images/pant-07.jpg",
    thumb: "assets/images/thumbs/pant-07.jpg",
    position: "center 55%",
    description: "",
    specs: spec("Heavy Weight Rigid Denim, Stretch Denim, Washed Denim")
  },
  {
    id: 8,
    name: "Linen Pants",
    image: "assets/images/pant-08.jpg",
    thumb: "assets/images/thumbs/pant-08.jpg",
    position: "center 60%",
    description: "",
    specs: spec("100% Linen, Cotton Linen Blend, Cotton Slub, Polyester Linen Blend")
  },
  {
    id: 9,
    name: "Formal Pants",
    image: "assets/images/pant-09.jpg",
    thumb: "assets/images/thumbs/pant-09.jpg",
    position: "center 60%",
    description: "",
    specs: spec("Polyester Suiting, Wool Blend Suiting, Cotton Stretch Twill")
  },
  {
    id: 10,
    name: "Cargo Pant Cotton with Rib",
    image: "assets/images/pant-10.jpg",
    thumb: "assets/images/thumbs/pant-10.jpg",
    position: "center 55%",
    description: "",
    specs: spec("Cotton Twill, Poly Cotton Twill, Cotton Ripstop, Rib Knit Fabric")
  },
  {
    id: 11,
    name: "Cargo Pant Cotton without Rib",
    image: "assets/images/pant-11.jpg",
    thumb: "assets/images/thumbs/pant-11.jpg",
    position: "center 55%",
    description: "",
    specs: spec("Cotton Twill, Poly Cotton Twill, Cotton Ripstop, Rib Knit Fabric")
  },
  {
    id: 12,
    name: "Cotton Pant",
    image: "assets/images/pant-12.jpg",
    thumb: "assets/images/thumbs/pant-12.jpg",
    position: "center 55%",
    description: "",
    specs: spec("Cotton Twill, Cotton Poplin, Cotton Canvas, Cotton Stretch, Cotton Dobby")
  },
  {
    id: 13,
    name: "Normal Fit",
    image: "assets/images/pant-13.jpg",
    thumb: "assets/images/thumbs/pant-13.jpg",
    position: "center 55%",
    description: "",
    specs: spec("Rigid Denim, Stretch Denim, Cotton Polyester Denim, Washed Denim")
  }
];
